public interface Convertable {

    double convert(double celsius, String targetScale);
}