public interface MenCloth {
    void dressMen();
}