public interface WomenCloth {
    void dressWomen();
}